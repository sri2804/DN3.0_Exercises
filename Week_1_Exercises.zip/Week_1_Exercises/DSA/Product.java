import java.util.Arrays;

// Product class definition
public class Product {
    private String productId;
    private String productName;
    private String category;

    public Product(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    // Getters
    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "ProductID: " + productId + ", Name: " + productName + ", Category: " + category;
    }


// SearchAlgorithms class definition
public static class SearchAlgorithms {

    // Linear Search
    public static Product linearSearch(Product[] products, String targetId) {
        for (Product product : products) {
            if (product.getProductId().equals(targetId)) {
                return product;
            }
        }
        return null; // Product not found
    }

    // Binary Search
    public static Product binarySearch(Product[] products, String targetId) {
        int low = 0;
        int high = products.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            Product midProduct = products[mid];

            if (midProduct.getProductId().equals(targetId)) {
                return midProduct;
            } else if (midProduct.getProductId().compareTo(targetId) < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null; // Product not found
    }
}

// Main class to demonstrate search functionality
    public static void main(String[] args) {
        // Creating sample products
        Product[] products = {
        	new Product("003", "Headphones", "Accessories"),
            
            new Product("002", "Smartphone", "Electronics"),
            new Product("001", "Laptop", "Electronics"),
           
        };

        // Display unsorted products
        System.out.println("Unsorted Products:");
        for (Product product : products) {
            System.out.println(product);
        }

        // Linear Search Example
        String searchIdLinear = "002";
        Product foundProductLinear = SearchAlgorithms.linearSearch(products, searchIdLinear);
        System.out.println("\nLinear Search Result:");
        System.out.println(foundProductLinear != null ? foundProductLinear : "Product not found");

        // Sorting products by productId for binary search
        Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));

        // Display sorted products
        System.out.println("\nSorted Products:");
        for (Product product : products) {
            System.out.println(product);
        }

        // Binary Search Example
        String searchIdBinary = "002";
        Product foundProductBinary = SearchAlgorithms.binarySearch(products, searchIdBinary);
        System.out.println("\nBinary Search Result:");
        System.out.println(foundProductBinary != null ? foundProductBinary : "Product not found");
    }
}

