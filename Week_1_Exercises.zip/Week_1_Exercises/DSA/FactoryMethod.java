public class FactoryMethod {

    // Abstract Document class
    abstract static class Document {
        // Method to describe the type of document
        public abstract void describe();
    }

    // Concrete class for Word documents
    static class WordDocument extends Document {
        @Override
        public void describe() {
            System.out.println("This is a Word document.");
        }
    }

    // Concrete class for PDF documents
    static class PdfDocument extends Document {
        @Override
        public void describe() {
            System.out.println("This is a PDF document.");
        }
    }

    // Concrete class for Excel documents
    static class ExcelDocument extends Document {
        @Override
        public void describe() {
            System.out.println("This is an Excel document.");
        }
    }

    // Abstract factory class
    abstract static class DocumentFactory {
        public abstract Document createDocument();
    }

    // Concrete factory class for Word documents
    static class WordDocumentFactory extends DocumentFactory {
        @Override
        public Document createDocument() {
            return new WordDocument();
        }
    }

    // Concrete factory class for PDF documents
    static class PdfDocumentFactory extends DocumentFactory {
        @Override
        public Document createDocument() {
            return new PdfDocument();
        }
    }

    // Concrete factory class for Excel documents
    static class ExcelDocumentFactory extends DocumentFactory {
        @Override
        public Document createDocument() {
            return new ExcelDocument();
        }
    }

    public static void main(String[] args) {
        // Create a Word document using the factory method
        DocumentFactory wordFactory = new WordDocumentFactory();
        Document wordDocument = wordFactory.createDocument();
        wordDocument.describe(); // Output: This is a Word document.

        // Create a PDF document using the factory method
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        Document pdfDocument = pdfFactory.createDocument();
        pdfDocument.describe(); // Output: This is a PDF document.

        // Create an Excel document using the factory method
        DocumentFactory excelFactory = new ExcelDocumentFactory();
        Document excelDocument = excelFactory.createDocument();
        excelDocument.describe(); // Output: This is an Excel document.
    }
}
