import java.util.HashMap;

public class InventoryManagement {

    // Product class definition
    public static class Product {
        private String productId;
        private String productName;
        private int quantity;
        private double price;

        public Product(String productId, String productName, int quantity, double price) {
            this.productId = productId;
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
        }

        // Getters and setters
        public String getProductId() {
            return productId;
        }

//        public void setProductId(String productId) {
//            this.productId = productId;
//        }

        public String getProductName() {
            return productName;
        }

        public void setProductName(String productName) {
            this.productName = productName;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        @Override
        public String toString() {
            return "ProductID: " + productId + ", Name: " + productName +
                   ", Quantity: " + quantity + ", Price: " + price;
        }
    }

    // InventoryManager class definition
    public static class InventoryManager {
        private HashMap<String, Product> inventory = new HashMap<>();

        // Add a new product
        public void addProduct(Product product) {
            inventory.put(product.getProductId(), product);
            System.out.println("Added: " + product);
        }

        // Update an existing product
        public void updateProduct(String productId, Product updatedProduct) {
            if (inventory.containsKey(productId)) {
                inventory.put(productId, updatedProduct);
                System.out.println("Updated: " + updatedProduct);
            } else {
                System.out.println("Product not found!");
            }
        }

        // Delete a product
        public void deleteProduct(String productId) {
            if (inventory.containsKey(productId)) {
                Product removedProduct = inventory.remove(productId);
                System.out.println("Deleted: " + removedProduct);
            } else {
                System.out.println("Product not found!");
            }
        }

        // Retrieve a product
        public Product getProduct(String productId) {
            return inventory.get(productId);
        }
    }

    // Main method to demonstrate functionality
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        // Creating products
        Product product1 = new Product("001", "Laptop", 10, 999.99);
        Product product2 = new Product("002", "Smartphone", 25, 499.99);
        Product product3 = new Product("003", "Headphones", 50, 89.99);

        // Adding products to inventory
        manager.addProduct(product1);
        manager.addProduct(product2);
        manager.addProduct(product3);

        // Retrieving and displaying a product
        System.out.println("Retrieved Product: " + manager.getProduct("002"));

        // Updating a product
        Product updatedProduct2 = new Product("002", "Smartphone", 20, 479.99);
        manager.updateProduct("002", updatedProduct2);

        // Deleting a product
        manager.deleteProduct("003");

        // Attempting to retrieve deleted product
        System.out.println("Retrieved Product: " + manager.getProduct("001"));
    }
}
