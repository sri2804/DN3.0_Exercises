public class FinancialForecasting {

    /**
     * Recursively calculates the future value based on the initial value, growth rate, and years.
     *
     * @param initialValue The initial value.
     * @param growthRate   The annual growth rate (as a decimal, e.g., 0.05 for 5%).
     * @param years        The number of years in the future.
     * @return The future value after the specified number of years.
     */
    public static double calculateFutureValue(double initialValue, double growthRate, int years) {
        // Base case: no more years to grow
        if (years == 0) return initialValue;
        
        // Recursive case: calculate the future value for one less year and apply growth rate
        return (1 + growthRate) * calculateFutureValue(initialValue, growthRate, years - 1);
    }

    public static void main(String[] args) {
        double initialValue = 1000.0; // Initial investment
        double growthRate = 0.05; // 5% annual growth rate
        int years = 10; // Forecast for 10 years

        double futureValue = calculateFutureValue(initialValue, growthRate, years);
        System.out.println("Future Value after " + years + " years: $" + futureValue);
    }
}
