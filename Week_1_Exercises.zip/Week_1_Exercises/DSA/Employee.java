public class Employee {
    private int employeeId;
    private String name;
    private String position;
    private double salary;

    public Employee(int employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee [employeeId=" + employeeId + ", name=" + name + ", position=" + position + ", salary=" + salary + "]";
    }



public static class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;
    private int capacity;

    public EmployeeManagementSystem(int capacity) {
        this.capacity = capacity;
        this.employees = new Employee[capacity];
        this.size = 0;
    }

    // Add an employee
    public void addEmployee(Employee employee) {
        if (size >= capacity) {
            System.out.println("Employee array is full. Cannot add more employees.");
            return;
        }
        employees[size] = employee;
        size++;
    }

    // Search for an employee by employeeId
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse and display all employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete an employee by employeeId
    public void deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[size - 1] = null;
                size--;
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);
        Employee emp1 = new Employee(1, "Sri", "Developer", 60000);
        Employee emp2 = new Employee(2, "John", "Designer", 55000);

        ems.addEmployee(emp1);
        ems.addEmployee(emp2);

        System.out.println("All Employees:");
        ems.traverseEmployees();

        System.out.println("Searching for employee with ID 1:");
        System.out.println(ems.searchEmployee(1));

        System.out.println("Deleting employee with ID 1:");
        ems.deleteEmployee(1);

        System.out.println("All Employees after deletion:");
        ems.traverseEmployees();
    }
}
}
