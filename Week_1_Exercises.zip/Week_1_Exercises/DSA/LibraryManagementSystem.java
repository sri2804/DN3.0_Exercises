import java.util.Arrays;
import java.util.Comparator;

public class LibraryManagementSystem {
    // Inner Book class to represent books
    public static class Book {
        private int bookId;
        private String title;
        private String author;

        public Book(int bookId, String title, String author) {
            this.bookId = bookId;
            this.title = title;
            this.author = author;
        }

        public int getBookId() {
            return bookId;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthor() {
            return author;
        }

        @Override
        public String toString() {
            return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + "]";
        }
    }

    private Book[] books;
    private int size;

    public LibraryManagementSystem(int capacity) {
        books = new Book[capacity];
        size = 0;
    }

    // Add a book to the library
    public void addBook(Book book) {
        if (size < books.length) {
            books[size++] = book;
        } else {
            System.out.println("Library is full, cannot add more books.");
        }
    }

    // Linear search for a book by title
    public Book linearSearchByTitle(String title) {
        for (int i = 0; i < size; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }

    // Binary search for a book by title (assumes the list is sorted)
    public Book binarySearchByTitle(String title) {
        // Ensure the array is sorted by title
        Arrays.sort(books, 0, size, Comparator.comparing(Book::getTitle));
        
        int left = 0;
        int right = size - 1;
        
        while (left <= right) {
            int mid = (left + right) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);
            
            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        LibraryManagementSystem library = new LibraryManagementSystem(10);
        library.addBook(new Book(1, "The Clock Work Princess", "Cassandra Clare"));
        library.addBook(new Book(2, "It Ends with us", "Coolen Hoover"));
        library.addBook(new Book(3, "You are my reason to smile", "Arprit Vaigieria"));

        System.out.println("Linear Search for 'The Clock Work Princess':");
        Book foundBook = library.linearSearchByTitle("The Clock Work Princess");
        if (foundBook != null) {
            System.out.println(foundBook);
        } else {
            System.out.println("Book not found.");
        }

        System.out.println("Binary Search for 'You are my reason to smile':");
        foundBook = library.binarySearchByTitle("You are my reason to smile");
        if (foundBook != null) {
            System.out.println(foundBook);
        } else {
            System.out.println("Book not found.");
        }
    }
}
