public class StrategyPattern {

    // Define the Strategy Interface
    interface PaymentStrategy {
        void pay(double amount);
    }

    // Implement Concrete Strategies
    static class CreditCardPayment implements PaymentStrategy {
        private String cardNumber;
        private String name;

        public CreditCardPayment(String cardNumber, String name) {
            this.cardNumber = cardNumber;
            this.name = name;
        }

        @Override
        public void pay(double amount) {
            System.out.println("Paying $" + amount + " using Credit Card.");
            System.out.println("Card Number: " + cardNumber);
            System.out.println("Cardholder Name: " + name);
        }
    }

    static class PayPalPayment implements PaymentStrategy {
        private String email;

        public PayPalPayment(String email) {
            this.email = email;
        }

        @Override
        public void pay(double amount) {
            System.out.println("Paying $" + amount + " using PayPal.");
            System.out.println("PayPal Email: " + email);
        }
    }

    // Implement the Context Class
    static class PaymentContext {
        private PaymentStrategy paymentStrategy;

        public PaymentContext(PaymentStrategy paymentStrategy) {
            this.paymentStrategy = paymentStrategy;
        }

        public void executePayment(double amount) {
            paymentStrategy.pay(amount);
        }
    }

    public static void main(String[] args) {
        // Create payment strategies
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "John Doe");
        PaymentStrategy payPalPayment = new PayPalPayment("john.doe@example.com");

        // Create payment context with Credit Card payment strategy
        PaymentContext paymentContext = new PaymentContext(creditCardPayment);
        System.out.println("Using Credit Card Payment Strategy:");
        paymentContext.executePayment(150.00);

        System.out.println();

        // Change payment strategy to PayPal
        paymentContext = new PaymentContext(payPalPayment);
        System.out.println("Using PayPal Payment Strategy:");
        paymentContext.executePayment(200.00);
    }
}
