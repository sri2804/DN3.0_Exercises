public class AdapterPattern {

    // Target interface
    interface PaymentProcessor {
        void processPayment(double amount);
    }

    // Adaptee class for Gateway A
    static class GatewayA {
        void makePayment(double amount) {
            System.out.println("Processing payment of $" + amount + " through Gateway A.");
        }
    }

    // Adaptee class for Gateway B
    static class GatewayB {
        void pay(double amount) {
            System.out.println("Processing payment of $" + amount + " through Gateway B.");
        }
    }

    // Adapter for Gateway A
    static class GatewayAAdapter implements PaymentProcessor {
        private GatewayA gatewayA;

        public GatewayAAdapter(GatewayA gatewayA) {
            this.gatewayA = gatewayA;
        }

        @Override
        public void processPayment(double amount) {
            gatewayA.makePayment(amount);
        }
    }

    // Adapter for Gateway B
    static class GatewayBAdapter implements PaymentProcessor {
        private GatewayB gatewayB;

        public GatewayBAdapter(GatewayB gatewayB) {
            this.gatewayB = gatewayB;
        }

        @Override
        public void processPayment(double amount) {
            gatewayB.pay(amount);
        }
    }

    public static void main(String[] args) {
        // Create instances of the gateways
        GatewayA gatewayA = new GatewayA();
        GatewayB gatewayB = new GatewayB();

        // Create adapters for the gateways
        PaymentProcessor adapterA = new GatewayAAdapter(gatewayA);
        PaymentProcessor adapterB = new GatewayBAdapter(gatewayB);

        // Use the adapters to process payments
        System.out.println("Using Gateway A Adapter:");
        adapterA.processPayment(150.00);

        System.out.println("\nUsing Gateway B Adapter:");
        adapterB.processPayment(200.00);
    }
}
