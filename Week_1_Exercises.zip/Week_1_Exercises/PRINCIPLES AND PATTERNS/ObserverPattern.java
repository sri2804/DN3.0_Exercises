import java.util.ArrayList;
import java.util.List;

// Define the Subject interface
interface Stock {
    void registerObserver(Observer observer);
    void deregisterObserver(Observer observer);
    void notifyObservers();
}

// Implement the Concrete Subject
class StockMarket implements Stock {
    private List<Observer> observers;
    private double price;

    public StockMarket() {
        observers = new ArrayList<>();
    }

    public void setPrice(double price) {
        this.price = price;
        notifyObservers();
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void deregisterObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(price);
        }
    }
}

// Define the Observer interface
interface Observer {
    void update(double price);
}

// Implement Concrete Observers
class MobileApp implements Observer {
    @Override
    public void update(double price) {
        System.out.println("MobileApp: Stock price updated to $" + price);
    }
}

class WebApp implements Observer {
    @Override
    public void update(double price) {
        System.out.println("WebApp: Stock price updated to $" + price);
    }
}

// Test the Observer implementation
public class ObserverPattern {

    public static void main(String[] args) {
        // Create the stock market (subject)
        StockMarket stockMarket = new StockMarket();

        // Create observers
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        // Register observers with the stock market
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        // Simulate stock price changes
        System.out.println("Updating stock prices:");
        stockMarket.setPrice(150.75); // Should notify all observers

        // Deregister the mobile app observer and update price again
        stockMarket.deregisterObserver(mobileApp);
        stockMarket.setPrice(160.50); // Should notify only WebApp
    }
}
