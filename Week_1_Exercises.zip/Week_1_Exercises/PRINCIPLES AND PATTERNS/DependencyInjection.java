public class DependencyInjection {

    // Define the Repository Interface
    interface CustomerRepository {
        String findCustomerById(int id);
    }

    // Implement the Concrete Repository
    static class CustomerRepositoryImpl implements CustomerRepository {
        @Override
        public String findCustomerById(int id) {
            // In a real application, this would query a database or other data source
            return "Customer with ID: " + id;
        }
    }

    // Define the Service Class
    static class CustomerService {
        private final CustomerRepository customerRepository;

        // Constructor Injection
        public CustomerService(CustomerRepository customerRepository) {
            this.customerRepository = customerRepository;
        }

        public String getCustomerDetails(int id) {
            return customerRepository.findCustomerById(id);
        }
    }

    // Main class to test the Dependency Injection implementation
    public static void main(String[] args) {
        // Create the repository
        CustomerRepository repository = new CustomerRepositoryImpl();

        // Inject the repository into the service
        CustomerService service = new CustomerService(repository);

        // Use the service to find a customer
        String customerDetails = service.getCustomerDetails(1);
        System.out.println(customerDetails);
    }
}
