public class BuilderPattern {

    // Product class
    public static class Computer {
        private final String CPU;
        private final String RAM;
        private final String storage;
        private final boolean isGraphicsCard;
        private final boolean isBluetooth;

        // Private constructor to be used by the Builder
        private Computer(Builder builder) {
            this.CPU = builder.CPU;
            this.RAM = builder.RAM;
            this.storage = builder.storage;
            this.isGraphicsCard = builder.isGraphicsCard;
            this.isBluetooth = builder.isBluetooth;
        }

        @Override
        public String toString() {
            return "Computer{" +
                    "CPU='" + CPU + '\'' +
                    ", RAM='" + RAM + '\'' +
                    ", Storage='" + storage + '\'' +
                    ", Graphics Card=" + (isGraphicsCard ? "Yes" : "No") +
                    ", Bluetooth=" + (isBluetooth ? "Yes" : "No") +
                    '}';
        }

        // Static nested Builder class
        public static class Builder {
            private String CPU;
            private String RAM;
            private String storage;
            private boolean isGraphicsCard;
            private boolean isBluetooth;

            // Method to set CPU
            public Builder setCPU(String CPU) {
                this.CPU = CPU;
                return this;
            }

            // Method to set RAM
            public Builder setRAM(String RAM) {
                this.RAM = RAM;
                return this;
            }

            // Method to set Storage
            public Builder setStorage(String storage) {
                this.storage = storage;
                return this;
            }

            // Method to set Graphics Card
            public Builder setGraphicsCard(boolean isGraphicsCard) {
                this.isGraphicsCard = isGraphicsCard;
                return this;
            }

            // Method to set Bluetooth
            public Builder setBluetooth(boolean isBluetooth) {
                this.isBluetooth = isBluetooth;
                return this;
            }

            // Build method to construct the Computer object
            public Computer build() {
                return new Computer(this);
            }
        }
    }

    public static void main(String[] args) {
        // Create a Computer with basic configuration
        Computer basicComputer = new Computer.Builder()
                .setCPU("Intel i5")
                .setRAM("8GB")
                .setStorage("256GB SSD")
                .build();

        // Create a Computer with all features
        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel i9")
                .setRAM("16GB")
                .setStorage("1TB SSD")
                .setGraphicsCard(true)
                .setBluetooth(true)
                .build();

        // Print the configurations
        System.out.println("Basic Computer Configuration:");
        System.out.println(basicComputer);

        System.out.println("\nGaming Computer Configuration:");
        System.out.println(gamingComputer);
    }
}
