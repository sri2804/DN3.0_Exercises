public class CommandPattern {

    // Define the Command interface
    interface Command {
        void execute();
    }

    // Implement the Receiver class
    static class Light {
        public void turnOn() {
            System.out.println("The light is now ON.");
        }

        public void turnOff() {
            System.out.println("The light is now OFF.");
        }
    }

    // Implement Concrete Commands
    static class LightOnCommand implements Command {
        private Light light;

        public LightOnCommand(Light light) {
            this.light = light;
        }

        @Override
        public void execute() {
            light.turnOn();
        }
    }

    static class LightOffCommand implements Command {
        private Light light;

        public LightOffCommand(Light light) {
            this.light = light;
        }

        @Override
        public void execute() {
            light.turnOff();
        }
    }

    // Implement the Invoker class
    static class RemoteControl {
        private Command command;

        public void setCommand(Command command) {
            this.command = command;
        }

        public void pressButton() {
            command.execute();
        }
    }

    public static void main(String[] args) {
        // Create the receiver
        Light light = new Light();

        // Create command objects
        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        // Create the invoker
        RemoteControl remote = new RemoteControl();

        // Turn the light on
        remote.setCommand(lightOn);
        System.out.println("Issuing Light On Command:");
        remote.pressButton();  // Should turn the light on

        System.out.println();

        // Turn the light off
        remote.setCommand(lightOff);
        System.out.println("Issuing Light Off Command:");
        remote.pressButton();  // Should turn the light off
    }
}
