public class TaskManagementSystem {
    // Inner Task class to store task information
    public static class Task {
        private int taskId;
        private String taskName;
        private String status;

        public Task(int taskId, String taskName, String status) {
            this.taskId = taskId;
            this.taskName = taskName;
            this.status = status;
        }

        public int getTaskId() {
            return taskId;
        }

        public String getTaskName() {
            return taskName;
        }

        public String getStatus() {
            return status;
        }

        @Override
        public String toString() {
            return "Task [taskId=" + taskId + ", taskName=" + taskName + ", status=" + status + "]";
        }
    }

    // Inner Node class to represent a node in the linked list
    private static class Node {
        Task task;
        Node next;

        Node(Task task) {
            this.task = task;
            this.next = null;
        }
    }

    private Node head;

    public TaskManagementSystem() {
        this.head = null;
    }

    // Add a task to the list
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search for a task by taskId
    public Task searchTask(int taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Traverse and display all tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete a task by taskId
    public void deleteTask(int taskId) {
        if (head == null) {
            return;
        }
        if (head.task.getTaskId() == taskId) {
            head = head.next;
            return;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.task.getTaskId() == taskId) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
        System.out.println("Task not found.");
    }

    public static void main(String[] args) {
        TaskManagementSystem tms = new TaskManagementSystem();
        Task task1 = new Task(1, "Design Module", "In Progress");
        Task task2 = new Task(2, "Develop Module", "Not Started");

        tms.addTask(task1);
        tms.addTask(task2);

        System.out.println("All Tasks:");
        tms.traverseTasks();

        System.out.println("Searching for task with ID 1:");
        Task foundTask = tms.searchTask(1);
        if (foundTask != null) {
            System.out.println(foundTask);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println("Deleting task with ID 1:");
        tms.deleteTask(1);

        System.out.println("All Tasks after deletion:");
        tms.traverseTasks();
    }
}
