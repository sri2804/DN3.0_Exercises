package com.example.employeemanagement.model;

public interface EmployeeProjection {
    Long getId();
    String getName();
}
